#!/usr/bin/env python3
import zipfile
from pathlib import Path

def extract_all_zips():
    cwd = Path.cwd()
    for zpath in cwd.glob("*.zip"):
        with zipfile.ZipFile(zpath, "r") as zf:
            zf.extractall(cwd)

if __name__ == "__main__":
    extract_all_zips()

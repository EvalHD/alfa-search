package de.netpulse.guard

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

data class ConnectionEvent(
    val timestamp: String,
    val appName: String,
    val packageName: String,
    val uid: Int,
    val protocol: String,
    val direction: String,
    val destination: String,
    val bytes: Int,
    val detail: String = ""
)

data class AppUsageStat(
    val uid: Int,
    val appName: String,
    val packageName: String,
    val isSystem: Boolean,
    val rxBytesSession: Long,
    val txBytesSession: Long,
    val rxRateBps: Long,
    val txRateBps: Long
)

object TrafficRepository {
    @Volatile var isRunning: Boolean = false
    @Volatile var totalRxBytes: Long = 0L
    @Volatile var totalTxBytes: Long = 0L
    @Volatile var inspectedPacketsCount: Long = 0L

    val connectionEvents = CopyOnWriteArrayList<ConnectionEvent>()
    val appUsageStats = CopyOnWriteArrayList<AppUsageStat>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun addConnectionEvent(
        appName: String,
        packageName: String,
        uid: Int,
        protocol: String,
        direction: String,
        destination: String,
        bytes: Int,
        detail: String = ""
    ) {
        val event = ConnectionEvent(
            timestamp = synchronized(timeFormat) { timeFormat.format(Date()) },
            appName = appName,
            packageName = packageName,
            uid = uid,
            protocol = protocol,
            direction = direction,
            destination = destination,
            bytes = bytes,
            detail = detail
        )
        connectionEvents.add(0, event)
        while (connectionEvents.size > 250) {
            connectionEvents.removeAt(connectionEvents.size - 1)
        }
        inspectedPacketsCount++
    }

    fun clearAll() {
        connectionEvents.clear()
        appUsageStats.clear()
        totalRxBytes = 0L
        totalTxBytes = 0L
        inspectedPacketsCount = 0L
    }
}

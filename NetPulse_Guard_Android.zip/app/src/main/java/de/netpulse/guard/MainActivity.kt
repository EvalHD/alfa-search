package de.netpulse.guard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var statusDot: TextView
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView
    private lateinit var toggleButton: Button
    private lateinit var rxMetricText: TextView
    private lateinit var txMetricText: TextView
    private lateinit var packetsMetricText: TextView
    private lateinit var tabAppsBtn: Button
    private lateinit var tabConnectionsBtn: Button
    private lateinit var listContainer: LinearLayout

    private var showAppsTab = true
    private val uiHandler = Handler(Looper.getMainLooper())

    private val vpnPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) startVpnMonitoringService()
    }

    private val refreshRunnable = object : Runnable {
        override fun run() {
            updateDashboardUi()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
        setContentView(buildRootLayout())
    }

    override fun onResume() {
        super.onResume()
        uiHandler.post(refreshRunnable)
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(refreshRunnable)
    }

    private fun buildRootLayout(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A0F1D"))
            setPadding(dp(16), dp(20), dp(16), dp(16))
        }

        val headerTitle = TextView(this).apply {
            text = "🛡️ NetPulse Guard"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#00F5D4"))
        }
        val headerSubtitle = TextView(this).apply {
            text = "Echtzeit-Verbindungs- & App-Datenmonitor (An/Ausschaltbar)"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(4), 0, dp(14))
        }
        root.addView(headerTitle)
        root.addView(headerSubtitle)

        val controlCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#131C31", "#1E293B", 16)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        statusDot = TextView(this).apply {
            text = "● "
            textSize = 18f
            setTextColor(Color.parseColor("#EF4444"))
        }
        statusTitle = TextView(this).apply {
            text = "Überwachung ist AUSGESCHALTET"
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        statusRow.addView(statusDot)
        statusRow.addView(statusTitle)

        statusSub = TextView(this).apply {
            text = "Tippen Sie auf den Schalter, um alle Verbindungen zu prüfen."
            textSize = 12f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(4), 0, dp(12))
        }

        toggleButton = Button(this).apply {
            text = "ÜBERWACHUNG EINSCHALTEN"
            setTextColor(Color.parseColor("#0A0F1D"))
            setTypeface(typeface, Typeface.BOLD)
            background = roundedBox("#00F5D4", "#00F5D4", 12)
            setOnClickListener {
                if (TrafficRepository.isRunning) stopVpnMonitoringService() else prepareAndStartVpn()
            }
        }

        controlCard.addView(statusRow)
        controlCard.addView(statusSub)
        controlCard.addView(toggleButton)
        root.addView(controlCard)

        val metricsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(12))
        }
        rxMetricText = createMetricCard(metricsRow, "↓ Empfangen", "0 B", "#10B981")
        txMetricText = createMetricCard(metricsRow, "↑ Gesendet", "0 B", "#38BDF8")
        packetsMetricText = createMetricCard(metricsRow, "🔍 DNS-Events", "0", "#F59E0B")
        root.addView(metricsRow)

        val tabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(10))
        }
        tabAppsBtn = Button(this).apply {
            text = "📱 Apps & System"
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) }
            setOnClickListener { showAppsTab = true; updateDashboardUi() }
        }
        tabConnectionsBtn = Button(this).apply {
            text = "🌐 Live-Verbindungen"
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(6) }
            setOnClickListener { showAppsTab = false; updateDashboardUi() }
        }
        tabsRow.addView(tabAppsBtn)
        tabsRow.addView(tabConnectionsBtn)
        root.addView(tabsRow)

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scrollView.addView(listContainer)
        root.addView(scrollView)
        return root
    }

    private fun createMetricCard(parent: LinearLayout, label: String, initialValue: String, valueColorHex: String): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#131C31", "#1E293B", 12)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) }
        }
        val titleView = TextView(this).apply { text = label; textSize = 11f; setTextColor(Color.parseColor("#94A3B8")) }
        val valueView = TextView(this).apply {
            text = initialValue; textSize = 15f; setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor(valueColorHex)); setPadding(0, dp(4), 0, 0)
        }
        card.addView(titleView); card.addView(valueView); parent.addView(card)
        return valueView
    }

    private fun updateDashboardUi() {
        val active = TrafficRepository.isRunning
        if (active) {
            statusDot.setTextColor(Color.parseColor("#10B981"))
            statusTitle.text = "Überwachung ist AKTIV"
            toggleButton.text = "ÜBERWACHUNG AUSSCHALTEN"
            toggleButton.setTextColor(Color.WHITE)
            toggleButton.background = roundedBox("#EF4444", "#DC2626", 12)
        } else {
            statusDot.setTextColor(Color.parseColor("#EF4444"))
            statusTitle.text = "Überwachung ist AUSGESCHALTET"
            toggleButton.text = "ÜBERWACHUNG EINSCHALTEN"
            toggleButton.setTextColor(Color.parseColor("#0A0F1D"))
            toggleButton.background = roundedBox("#00F5D4", "#00F5D4", 12)
        }

        rxMetricText.text = formatBytes(TrafficRepository.totalRxBytes)
        txMetricText.text = formatBytes(TrafficRepository.totalTxBytes)
        packetsMetricText.text = TrafficRepository.inspectedPacketsCount.toString()

        if (showAppsTab) renderAppTrafficList() else renderConnectionsList()
    }

    private fun renderAppTrafficList() {
        listContainer.removeAllViews()
        for (item in TrafficRepository.appUsageStats.take(50)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#131C31", "#1E293B", 12)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            }
            val title = TextView(this).apply {
                text = "${item.appName} (UID ${item.uid})"
                textSize = 14f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE)
            }
            val speedView = TextView(this).apply {
                text = "Live: ↓ ${formatBytes(item.rxRateBps)}/s | ↑ ${formatBytes(item.txRateBps)}/s  (Gesamt: ↓ ${formatBytes(item.rxBytesSession)} / ↑ ${formatBytes(item.txBytesSession)})"
                textSize = 12f; setTextColor(Color.parseColor("#00F5D4"))
            }
            row.addView(title); row.addView(speedView); listContainer.addView(row)
        }
    }

    private fun renderConnectionsList() {
        listContainer.removeAllViews()
        for (ev in TrafficRepository.connectionEvents.take(60)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#131C31", "#1E293B", 12)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            }
            val topLine = TextView(this).apply {
                text = "[${ev.timestamp}] ${ev.direction} • ${ev.appName} -> ${ev.destination} (${ev.bytes} B)"
                textSize = 12f; setTextColor(Color.WHITE)
            }
            row.addView(topLine); listContainer.addView(row)
        }
    }

    private fun prepareAndStartVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermissionLauncher.launch(intent) else startVpnMonitoringService()
    }

    private fun startVpnMonitoringService() {
        ContextCompat.startForegroundService(this, Intent(this, NetPulseVpnService::class.java).apply { action = NetPulseVpnService.ACTION_START })
    }

    private fun stopVpnMonitoringService() {
        startService(Intent(this, NetPulseVpnService::class.java).apply { action = NetPulseVpnService.ACTION_STOP })
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        return String.format(Locale.US, "%.2f MB", kb / 1024.0)
    }

    private fun roundedBox(fillHex: String, strokeHex: String, radiusDp: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.parseColor(fillHex))
            setStroke(dp(1), Color.parseColor(strokeHex))
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

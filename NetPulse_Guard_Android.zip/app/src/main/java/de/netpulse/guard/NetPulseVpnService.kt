package de.netpulse.guard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class NetPulseVpnService : VpnService() {
    companion object {
        const val ACTION_START = "de.netpulse.guard.ACTION_START"
        const val ACTION_STOP = "de.netpulse.guard.ACTION_STOP"
        private const val CHANNEL_ID = "netpulse_vpn_channel"
        private const val NOTIFICATION_ID = 1001
        private const val VPN_CLIENT_IP = "10.215.173.1"
        private const val VIRTUAL_DNS_IP = "10.215.173.2"
        private const val UPSTREAM_DNS_IP = "1.1.1.1"
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var vpnThread: Thread? = null
    private var statsThread: Thread? = null
    private val uidCache = mutableMapOf<Int, Triple<String, String, Boolean>>()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running.get()) startMonitoring()
        return START_STICKY
    }

    private fun startMonitoring() {
        createNotificationChannel()
        val notification = buildNotification("Überwachung aktiv – 0% Leistungsverlust")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val builder = Builder()
            .setSession("NetPulse Guard")
            .addAddress(VPN_CLIENT_IP, 30)
            .addRoute(VIRTUAL_DNS_IP, 32)
            .addDnsServer(VIRTUAL_DNS_IP)
            .setMtu(1500)
            .setBlocking(true)

        vpnInterface = builder.establish() ?: run {
            stopSelf()
            return
        }

        running.set(true)
        TrafficRepository.isRunning = true
        vpnThread = thread(start = true) { runTunnelLoop() }
        statsThread = thread(start = true) { runAppTrafficTracker() }
    }

    private fun runTunnelLoop() {
        val pfd = vpnInterface ?: return
        val inputStream = FileInputStream(pfd.fileDescriptor)
        val outputStream = FileOutputStream(pfd.fileDescriptor)
        val packetBuffer = ByteArray(32767)
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        try {
            while (running.get()) {
                val length = inputStream.read(packetBuffer)
                if (length <= 0) continue
                val version = (packetBuffer[0].toInt() ushr 4) and 0x0F
                if (version != 4 || length < 28) continue
                val ihl = (packetBuffer[0].toInt() and 0x0F) * 4
                val protocol = packetBuffer[9].toInt() and 0xFF
                if (protocol != 17 || length < ihl + 8) continue

                val srcIpBytes = packetBuffer.copyOfRange(12, 16)
                val dstIpBytes = packetBuffer.copyOfRange(16, 20)
                val srcPort = ((packetBuffer[ihl].toInt() and 0xFF) shl 8) or (packetBuffer[ihl + 1].toInt() and 0xFF)
                val dstPort = ((packetBuffer[ihl + 2].toInt() and 0xFF) shl 8) or (packetBuffer[ihl + 3].toInt() and 0xFF)

                val payloadOffset = ihl + 8
                val payloadLen = length - payloadOffset
                if (payloadLen <= 0) continue
                val udpPayload = packetBuffer.copyOfRange(payloadOffset, length)

                var ownerUid = -1
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    try {
                        val localAddr = InetSocketAddress(InetAddress.getByAddress(srcIpBytes), srcPort)
                        val remoteAddr = InetSocketAddress(InetAddress.getByAddress(dstIpBytes), dstPort)
                        ownerUid = connectivityManager.getConnectionOwnerUid(OsConstants.IPPROTO_UDP, localAddr, remoteAddr)
                    } catch (_: Exception) {}
                }

                val (appName, pkgName, _) = resolveUidInfo(ownerUid)
                val queriedDomain = PacketParser.extractDnsQueryDomain(udpPayload, payloadLen) ?: "UDP:$dstPort"

                TrafficRepository.addConnectionEvent(appName, pkgName, ownerUid, "DNS/UDP", "AUSGEHEND ↑", queriedDomain, length)

                thread(start = true) {
                    forwardDnsAndRespond(srcIpBytes, dstIpBytes, srcPort, dstPort, udpPayload, payloadLen, appName, pkgName, ownerUid, queriedDomain, outputStream)
                }
            }
        } catch (_: Exception) {}
    }

    private fun forwardDnsAndRespond(
        srcIpBytes: ByteArray, dstIpBytes: ByteArray, srcPort: Int, dstPort: Int,
        udpPayload: ByteArray, payloadLen: Int, appName: String, pkgName: String,
        ownerUid: Int, queriedDomain: String, outputStream: FileOutputStream
    ) {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            protect(socket)
            socket.soTimeout = 4000
            val upstreamAddr = InetAddress.getByName(UPSTREAM_DNS_IP)
            socket.send(DatagramPacket(udpPayload, payloadLen, upstreamAddr, 53))

            val responseBuf = ByteArray(1500)
            val inPacket = DatagramPacket(responseBuf, responseBuf.size)
            socket.receive(inPacket)

            val replyBytes = PacketParser.buildIpv4UdpPacket(dstIpBytes, srcIpBytes, dstPort, srcPort, responseBuf, inPacket.length)
            synchronized(outputStream) { outputStream.write(replyBytes) }

            TrafficRepository.addConnectionEvent(appName, pkgName, ownerUid, "DNS/UDP", "EINGEHEND ↓", queriedDomain, replyBytes.size)
        } catch (_: Exception) {
        } finally {
            socket?.close()
        }
    }

    private fun runAppTrafficTracker() {
        val pm = packageManager
        val baselineRx = mutableMapOf<Int, Long>()
        val baselineTx = mutableMapOf<Int, Long>()
        val prevRx = mutableMapOf<Int, Long>()
        val prevTx = mutableMapOf<Int, Long>()
        val globalStartRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
        val globalStartTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)

        while (running.get()) {
            try {
                val installedApps = pm.getInstalledApplications(0)
                val currentStats = mutableListOf<AppUsageStat>()
                val seenUids = HashSet<Int>()

                TrafficRepository.totalRxBytes = (TrafficStats.getTotalRxBytes().coerceAtLeast(0L) - globalStartRx).coerceAtLeast(0L)
                TrafficRepository.totalTxBytes = (TrafficStats.getTotalTxBytes().coerceAtLeast(0L) - globalStartTx).coerceAtLeast(0L)

                for (app in installedApps) {
                    val uid = app.uid
                    if (!seenUids.add(uid)) continue
                    val rxNow = TrafficStats.getUidRxBytes(uid)
                    val txNow = TrafficStats.getUidTxBytes(uid)
                    if (rxNow <= 0L && txNow <= 0L) continue

                    val baseR = baselineRx.getOrPut(uid) { rxNow }
                    val baseT = baselineTx.getOrPut(uid) { txNow }
                    val lastR = prevRx.getOrPut(uid) { rxNow }
                    val lastT = prevTx.getOrPut(uid) { txNow }

                    val sessionRx = (rxNow - baseR).coerceAtLeast(0L)
                    val sessionTx = (txNow - baseT).coerceAtLeast(0L)
                    val rateRx = ((rxNow - lastR).coerceAtLeast(0L)) / 2L
                    val rateTx = ((txNow - lastT).coerceAtLeast(0L)) / 2L

                    prevRx[uid] = rxNow
                    prevTx[uid] = txNow

                    if (sessionRx > 0L || sessionTx > 0L || rateRx > 0L || rateTx > 0L) {
                        val (appName, pkgName, isSys) = resolveUidInfo(uid)
                        currentStats.add(AppUsageStat(uid, appName, pkgName, isSys, sessionRx, sessionTx, rateRx, rateTx))
                    }
                }

                currentStats.sortWith(compareByDescending<AppUsageStat> { it.rxRateBps + it.txRateBps }.thenByDescending { it.rxBytesSession + it.txBytesSession })
                TrafficRepository.appUsageStats.clear()
                TrafficRepository.appUsageStats.addAll(currentStats)
                Thread.sleep(2000L)
            } catch (_: InterruptedException) { break } catch (_: Exception) {}
        }
    }

    private fun resolveUidInfo(uid: Int): Triple<String, String, Boolean> {
        if (uid <= 0) return Triple("Android-System / Kernel", "android.system", true)
        if (uid == 1000) return Triple("Android-System (UID 1000)", "android.system", true)
        uidCache[uid]?.let { return it }
        val pm = packageManager
        val packages = pm.getPackagesForUid(uid)
        if (!packages.isNullOrEmpty()) {
            val pkg = packages[0]
            try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                val label = pm.getApplicationLabel(appInfo).toString()
                val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val result = Triple(label, pkg, isSys)
                uidCache[uid] = result
                return result
            } catch (_: Exception) {}
        }
        return Triple("System-Prozess (UID $uid)", "uid:$uid", true)
    }

    private fun stopMonitoring() {
        running.set(false)
        TrafficRepository.isRunning = false
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        vpnThread?.interrupt()
        statsThread?.interrupt()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        stopMonitoring()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "NetPulse Guard", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = Intent(this, NetPulseVpnService::class.java).apply { action = ACTION_STOP }
        val pendingStop = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NetPulse Guard aktiv")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_secure)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Ausschalten", pendingStop)
            .build()
    }
}

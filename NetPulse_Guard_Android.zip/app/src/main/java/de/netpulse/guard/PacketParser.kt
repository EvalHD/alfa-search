package de.netpulse.guard

import java.net.InetAddress
import java.nio.ByteBuffer

object PacketParser {
    fun extractDnsQueryDomain(udpPayload: ByteArray, length: Int): String? {
        if (length < 17) return null
        val parts = mutableListOf<String>()
        var pos = 12
        while (pos < length) {
            val labelLen = udpPayload[pos].toInt() and 0xFF
            if (labelLen == 0) break
            if ((labelLen and 0xC0) != 0 || pos + 1 + labelLen > length) return null
            val label = String(udpPayload, pos + 1, labelLen, Charsets.UTF_8)
            parts.add(label)
            pos += 1 + labelLen
        }
        return if (parts.isEmpty()) null else parts.joinToString(".")
    }

    fun buildIpv4UdpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray,
        payloadLen: Int
    ): ByteArray {
        val totalLen = 20 + 8 + payloadLen
        val buffer = ByteBuffer.allocate(totalLen)
        buffer.put((0x45).toByte())
        buffer.put(0.toByte())
        buffer.putShort(totalLen.toShort())
        buffer.putShort(0.toShort())
        buffer.putShort(0x4000.toShort())
        buffer.put(64.toByte())
        buffer.put(17.toByte())
        buffer.putShort(0.toShort())
        buffer.put(srcIp)
        buffer.put(dstIp)

        val raw = buffer.array()
        val ipChecksum = computeIpChecksum(raw, 0, 20)
        buffer.putShort(10, ipChecksum)

        val udpLen = 8 + payloadLen
        buffer.putShort(srcPort.toShort())
        buffer.putShort(dstPort.toShort())
        buffer.putShort(udpLen.toShort())
        buffer.putShort(0.toShort())
        buffer.put(payload, 0, payloadLen)
        return raw
    }

    private fun u16(d: ByteArray, i: Int): Int =
        ((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)

    private fun u32(d: ByteArray, i: Int): Long =
        ((d[i].toLong() and 0xFF) shl 24) or ((d[i + 1].toLong() and 0xFF) shl 16) or
            ((d[i + 2].toLong() and 0xFF) shl 8) or (d[i + 3].toLong() and 0xFF)

    private fun readName(data: ByteArray, length: Int, start: Int): Pair<String, Int> {
        val sb = StringBuilder()
        var pos = start
        var endPos = -1
        var jumps = 0
        while (pos < length) {
            val len = data[pos].toInt() and 0xFF
            if (len == 0) {
                if (endPos < 0) endPos = pos + 1
                break
            }
            if ((len and 0xC0) == 0xC0) {
                if (pos + 1 >= length || jumps++ > 10) break
                val ptr = ((len and 0x3F) shl 8) or (data[pos + 1].toInt() and 0xFF)
                if (endPos < 0) endPos = pos + 2
                pos = ptr
                continue
            }
            if (pos + 1 + len > length) break
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(data, pos + 1, len, Charsets.UTF_8))
            pos += 1 + len
        }
        if (endPos < 0) endPos = pos
        return Pair(sb.toString(), endPos)
    }

    private fun typeName(t: Int): String = when (t) {
        1 -> "A (IPv4-Adresse)"
        2 -> "NS"
        5 -> "CNAME (Weiterleitung)"
        6 -> "SOA"
        12 -> "PTR"
        15 -> "MX"
        16 -> "TXT"
        28 -> "AAAA (IPv6-Adresse)"
        33 -> "SRV"
        65 -> "HTTPS"
        else -> "Typ $t"
    }

    private fun rcodeName(r: Int): String = when (r) {
        0 -> "OK (kein Fehler)"
        1 -> "Formatfehler"
        2 -> "Serverfehler"
        3 -> "Domain existiert nicht (NXDOMAIN)"
        5 -> "Abgelehnt"
        else -> "Code $r"
    }

    fun describeDnsMessage(data: ByteArray, length: Int): String {
        if (length < 12 || data.size < length) return "Kein gültiges DNS-Paket ($length Bytes)"
        val sb = StringBuilder()
        try {
            val flags = u16(data, 2)
            val isResponse = (flags and 0x8000) != 0
            val qd = u16(data, 4)
            val an = u16(data, 6)
            sb.append("Art: ").append(if (isResponse) "DNS-ANTWORT (empfangen)" else "DNS-ANFRAGE (gesendet)").append('\n')
            sb.append("Transaktions-ID: ").append(u16(data, 0)).append('\n')
            if (isResponse) sb.append("Status: ").append(rcodeName(flags and 0x000F)).append('\n')
            var pos = 12
            for (i in 0 until minOf(qd, 5)) {
                val q = readName(data, length, pos)
                if (q.second + 4 > length) break
                sb.append("Gefragt nach: ").append(q.first).append("  [").append(typeName(u16(data, q.second))).append("]\n")
                pos = q.second + 4
            }
            if (isResponse) {
                sb.append("Anzahl Antworten: ").append(an).append('\n')
                for (i in 0 until minOf(an, 20)) {
                    if (pos >= length) break
                    val n = readName(data, length, pos)
                    val next = n.second
                    if (next + 10 > length) break
                    val type = u16(data, next)
                    val ttl = u32(data, next + 4)
                    val rdLen = u16(data, next + 8)
                    val rd = next + 10
                    if (rd + rdLen > length) break
                    val value = when {
                        type == 1 && rdLen == 4 -> (0 until 4).joinToString(".") { (data[rd + it].toInt() and 0xFF).toString() }
                        type == 28 && rdLen == 16 -> InetAddress.getByAddress(data.copyOfRange(rd, rd + 16)).hostAddress ?: "?"
                        type == 2 || type == 5 || type == 12 -> readName(data, length, rd).first
                        else -> "$rdLen Bytes Daten"
                    }
                    sb.append("  • ").append(n.first).append("  →  ").append(value)
                        .append("   (").append(typeName(type)).append(", TTL ").append(ttl).append("s)\n")
                    pos = rd + rdLen
                }
            }
        } catch (e: Exception) {
            sb.append("(Paket konnte nicht vollständig gelesen werden)\n")
        }
        return sb.toString()
    }

    fun hexDump(data: ByteArray, length: Int, maxBytes: Int = 192): String {
        val n = minOf(length, maxBytes, data.size)
        val sb = StringBuilder()
        var i = 0
        while (i < n) {
            sb.append(String.format("%04X  ", i))
            val hex = StringBuilder()
            val asc = StringBuilder()
            for (j in i until minOf(i + 16, n)) {
                val b = data[j].toInt() and 0xFF
                hex.append(String.format("%02X ", b))
                asc.append(if (b in 32..126) b.toChar() else '.')
            }
            sb.append(hex.toString().padEnd(48)).append(asc).append('\n')
            i += 16
        }
        if (length > n) sb.append("... (").append(length - n).append(" weitere Bytes nicht angezeigt)\n")
        return sb.toString()
    }

    private fun computeIpChecksum(data: ByteArray, offset: Int, length: Int): Short {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            sum += word
            if ((sum and 0xFFFF0000L) != 0L) {
                sum = (sum and 0xFFFFL) + (sum shr 16)
            }
            i += 2
        }
        return (sum.inv() and 0xFFFFL).toShort()
    }
}

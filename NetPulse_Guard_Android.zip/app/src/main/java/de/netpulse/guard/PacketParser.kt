package de.netpulse.guard

import java.nio.ByteBuffer

object PacketParser {
    fun extractDnsQueryDomain(udpPayload: ByteArray, length: Int): String? {
        if (length < 17) return null
        val parts = mutableListOf<String>()
        var pos = 12
        while (pos < length) {
            val labelLen = udpPayload[pos].toInt() and 0xFF
            if (labelLen == 0) break
            if ((labelLen and 0xC0) != 0 || pos + 1 + labelLen > length) return null
            val label = String(udpPayload, pos + 1, labelLen, Charsets.UTF_8)
            parts.add(label)
            pos += 1 + labelLen
        }
        return if (parts.isEmpty()) null else parts.joinToString(".")
    }

    fun buildIpv4UdpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray,
        payloadLen: Int
    ): ByteArray {
        val totalLen = 20 + 8 + payloadLen
        val buffer = ByteBuffer.allocate(totalLen)
        buffer.put((0x45).toByte())
        buffer.put(0.toByte())
        buffer.putShort(totalLen.toShort())
        buffer.putShort(0.toShort())
        buffer.putShort(0x4000.toShort())
        buffer.put(64.toByte())
        buffer.put(17.toByte())
        buffer.putShort(0.toShort())
        buffer.put(srcIp)
        buffer.put(dstIp)

        val raw = buffer.array()
        val ipChecksum = computeIpChecksum(raw, 0, 20)
        buffer.putShort(10, ipChecksum)

        val udpLen = 8 + payloadLen
        buffer.putShort(srcPort.toShort())
        buffer.putShort(dstPort.toShort())
        buffer.putShort(udpLen.toShort())
        buffer.putShort(0.toShort())
        buffer.put(payload, 0, payloadLen)
        return raw
    }

    private fun computeIpChecksum(data: ByteArray, offset: Int, length: Int): Short {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            sum += word
            if ((sum and 0xFFFF0000L) != 0L) {
                sum = (sum and 0xFFFFL) + (sum shr 16)
            }
            i += 2
        }
        return (sum.inv() and 0xFFFFL).toShort()
    }
}

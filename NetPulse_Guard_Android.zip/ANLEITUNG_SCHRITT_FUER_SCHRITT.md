# 🛡️ NetPulse Guard – Detaillierte Schritt-für-Schritt-Anleitung

1. Erstellen Sie auf https://github.com ein neues Repository (z. B. "NetPulse-Guard").
2. Laden Sie diese Datei (NetPulse_Guard_Android.zip) per "Add file" -> "Upload files" direkt in Ihr Repository hoch.
3. Legen Sie über "Add file" -> "Create new file" die Datei ".github/workflows/build_android_apk.yml" an (Inhalt befindet sich ebenfalls in dieser ZIP).
4. GitHub entpackt die ZIP unter "Actions" automatisch und baut für Sie in 2 Minuten die fertige Android-App (app-debug.apk).

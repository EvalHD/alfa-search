# NetPulse Guard - Anleitung

1. Auf github.com ein neues Repository anlegen (z. B. "NetPulse-Guard").
2. "Add file" -> "Create new file", als Dateiname exakt
   `.github/workflows/build.yml` eingeben und den Inhalt von
   `.github/workflows/build_android_apk.yml` einfuegen. "Commit changes".
3. "Add file" -> "Upload files": diese ZIP (NetPulse_Guard_Android.zip) hochladen, "Commit changes".
4. Reiter "Actions": der Build startet automatisch, GitHub entpackt die ZIP selbst.
5. Nach ca. 3-6 Minuten den Lauf oeffnen -> unten bei "Artifacts" `NetPulse-Guard-APK` herunterladen,
   entpacken, `app-debug.apk` installieren (Installation aus unbekannten Quellen erlauben).
